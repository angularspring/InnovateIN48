// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  /*AUTH_SERVICE: "http://lbmdevfisblr01:50406/authentication",
  USER_ROLE: "http://lbmdevfisblr01:50406/Innovate/user/role"*/

  AUTH_SERVICE: "http://localhost:8080/authentication",
  USER_ROLE: "http://localhost:8080/Innovate/user/details",
  BRANCH_DETAILS: "http://localhost:8080/Innovate/branch/details",
  PROCESS_CUST: "http://localhost:8080/Innovate/branch/custVisit",
  PROCESS_CUST_LEAVE: "http://localhost:8080/Innovate/branch/custLeave",
  CUST_NOTIFICATION: "http://localhost:8080/Innovate/msg/bank/custAlert",
  ATM_CUST_NOTIFICATION: "http://localhost:8080/Innovate/msg/bank/atmVisitAlert",
  BRANCH_MSG: "http://localhost:8080/Innovate/msg/bank/saveBranchMsg",
  CUST_ALLOCATION: "http://localhost:8080/Innovate/msg/bank/custAllocation"
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
