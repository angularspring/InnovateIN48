export class Customer {
    public custId:string;
    public custName:string;
    public custType:string;

    public getCustId(): string{
        return this.custId;
    }
    public setCustId(custIdVal:string): void{
        this.custId = custIdVal;
    }
    public getCustName(): string{
        return this.custName;
    }
    public setCustName(custNameVal:string): void{
        this.custName = custNameVal;
    }

    public getCustType(): string{
        return this.custType;
    }
    public setCustType(custTypeVal:string): void{
        this.custType = custTypeVal;
    }
}