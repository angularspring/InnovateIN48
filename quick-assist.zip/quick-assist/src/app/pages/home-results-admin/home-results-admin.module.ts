import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';

import { PopmenuComponent } from './../../components/popmenu-admin/popmenu.component';

import { HomeResultsAdminPage } from './home-results-admin.page';

const routes: Routes = [
  {
    path: '',
    component: HomeResultsAdminPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [HomeResultsAdminPage, PopmenuComponent]
})
export class HomeResultsAdminPageModule {}
