import { Component } from '@angular/core';
import {
  NavController,
  AlertController,
  MenuController,
  ToastController,
  PopoverController,
  ModalController } from '@ionic/angular';

// Modals
import { SearchFilterPage } from '../../pages/modal/search-filter/search-filter.page';
import { ImagePage } from './../modal/image/image.page';
// Call notifications test by Popover and Custom Component.
import { NotificationsComponent } from './../../components/notifications/notifications.component';
import { HttpService } from './../../services/http.service'
import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import { Customer } from './../../model/Customer';
import { UserService } from './../../services/user.service'

@Component({
  selector: 'app-home-results',
  templateUrl: './home-results-admin.page.html',
  styleUrls: ['./home-results-admin.page.scss']
})
export class HomeResultsAdminPage {
  searchKey = '';
  yourLocation = 'Orchard Road, Bangkok';
  themeCover = 'assets/img/ionic4-Start-Theme-cover.jpg';
  cust: Customer;
  isNewCust:boolean = false;
  isCustSubmitted:boolean = false;
  estTime: any = '2';
  estTimeList: any = ['2', '5', '10'];
  msg = '';
  userId = this.userService.getUser().getUserId();

  constructor(
    public navCtrl: NavController,
    public menuCtrl: MenuController,
    public popoverCtrl: PopoverController,
    public alertCtrl: AlertController,
    public modalCtrl: ModalController,
    public toastCtrl: ToastController,
    private httpService: HttpService,
    private userService: UserService
  ) {

  }

  ngOnInit() {
    IntervalObservable.create(6000).subscribe(() => {
      this.httpService.getCustNotification({id : this.userId }).subscribe( (response) => {
        if(response != null){
          this.isCustSubmitted = false;
          this.isNewCust = true;
          this.cust = response;
        }
      })
    })
    
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(true);
  }

  settings() {
    this.navCtrl.navigateForward('settings');
  }

  async alertLocation() {
    const changeLocation = await this.alertCtrl.create({
      header: 'Change Location',
      message: 'Type your Address.',
      inputs: [
        {
          name: 'location',
          placeholder: 'Enter your new Location',
          type: 'text'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Change',
          handler: async (data) => {
            console.log('Change clicked', data);
            this.yourLocation = data.location;
            const toast = await this.toastCtrl.create({
              message: 'Location was change successfully',
              duration: 3000,
              position: 'top',
              closeButtonText: 'OK',
              showCloseButton: true
            });

            toast.present();
          }
        }
      ]
    });
    changeLocation.present();
  }

  async searchFilter () {
    const modal = await this.modalCtrl.create({
      component: SearchFilterPage
    });
    return await modal.present();
  }

  async presentImage(image: any) {
    const modal = await this.modalCtrl.create({
      component: ImagePage,
      componentProps: { value: image }
    });
    return await modal.present();
  }

  async notifications(ev: any) {
    const popover = await this.popoverCtrl.create({
      component: NotificationsComponent,
      event: ev,
      animated: true,
      showBackdrop: true
    });
    return await popover.present();
  }

  onSubmit(){
    
    let data = {
      custId: this.cust.custId,
      branchEmpName: this.userService.getUser().getUserName(),
      estTime: this.estTime
    }

    this.httpService.saveBranchMsg(data).subscribe((response) => {
      if(response != null){
        this.isNewCust = false;
        this.isCustSubmitted = true;
        this.msg = "OTP for this customer is "+ response;
        
      }else{
        this.isNewCust = true;
        this.isCustSubmitted = false;
      }
     })
  }

}
