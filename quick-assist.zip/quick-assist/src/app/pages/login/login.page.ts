import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController, MenuController, ToastController, AlertController, LoadingController } from '@ionic/angular';
import { HttpService } from './../../services/http.service'
import { UserService } from './../../services/user.service'
import { User } from './../../model/User';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  public onLoginForm: FormGroup;
  
  public isNotValidAuth: boolean = false;

  constructor(
    public navCtrl: NavController,
    public menuCtrl: MenuController,
    public toastCtrl: ToastController,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    private formBuilder: FormBuilder,
    private httpService: HttpService,
    private userService: UserService,
    public plt: Platform
  ) { }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }

  ngOnInit() {

    console.log(this.plt.platforms());
    console.log(this.plt.is('ios'));
    this.onLoginForm = this.formBuilder.group({
      'email': [null, Validators.compose([
        Validators.required
      ])],
      'password': [null, Validators.compose([
        Validators.required
      ])]
    });
  }

  async forgotPass() {
    const alert = await this.alertCtrl.create({
      header: 'Forgot Password?',
      message: 'Enter you email address to send a reset link password.',
      inputs: [
        {
          name: 'email',
          type: 'email',
          placeholder: 'Email'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Confirm',
          handler: async () => {
            const loader = await this.loadingCtrl.create({
              duration: 2000
            });

            loader.present();
            loader.onWillDismiss().then(async l => {
              const toast = await this.toastCtrl.create({
                showCloseButton: true,
                message: 'Email was sended successfully.',
                duration: 3000,
                position: 'bottom'
              });

              toast.present();
            });
          }
        }
      ]
    });

    await alert.present();
  }

  // // //
  goToRegister() {
    this.navCtrl.navigateRoot('/register');
  }

  goToHome() {
    let user:User;
    let data ="secure_username=" + this.onLoginForm.value.email +"&secure_keyword=" +this.onLoginForm.value.password;
    this.httpService.authenticate(data).subscribe( (response) => {
      if(response.body.message === 'Success'){
        this.httpService.getUserRole({id : this.onLoginForm.value.email }).subscribe( (response) => {
          user = new User();
          user.setUserId(this.onLoginForm.value.email);
          user.setUserName(response.data.userName);
          user.setRole(response.data.role);
          this.userService.setUser(user);
          if(response.data.role === "C"){
            this.navCtrl.navigateRoot('/home-results');
          }else{
            this.navCtrl.navigateRoot('/home-results-admin');
          }
        })
       }else{
        this.isNotValidAuth =true;
      }
    })
    
  }

}
