import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './refId.page.html',
  styleUrls: ['./refId.page.scss'],
})
export class RefIdPage implements OnInit {

  isHome:boolean = true;
  isTrans:boolean = false;
  isSuccess:boolean = false;

  constructor() { }

  ngOnInit() {
  }

  onClickHome(){
    this.isHome = false;
    this.isTrans = true;
    this.isSuccess = false;
  }

  onClickTrans(){
    this.isHome = false;
    this.isTrans = false;
    this.isSuccess = true;
  }



}
