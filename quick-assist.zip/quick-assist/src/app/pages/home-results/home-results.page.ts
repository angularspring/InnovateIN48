import { Component } from '@angular/core';
import {
  NavController,
  AlertController,
  MenuController,
  ToastController,
  PopoverController,
  ModalController } from '@ionic/angular';

// Modals
import { SearchFilterPage } from '../../pages/modal/search-filter/search-filter.page';
import { ImagePage } from './../modal/image/image.page';
// Call notifications test by Popover and Custom Component.
import { NotificationsComponent } from './../../components/notifications/notifications.component';
import { UserService } from './../../services/user.service'
import { HttpService } from './../../services/http.service'
import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import { SpeechSynthesisUtteranceFactoryService, SpeechSynthesisService } from '@kamiazya/ngx-speech-synthesis';


@Component({
  selector: 'app-home-results',
  templateUrl: './home-results.page.html',
  styleUrls: ['./home-results.page.scss'],
  providers: [ SpeechSynthesisUtteranceFactoryService]
})
export class HomeResultsPage {
  searchKey = '';
  userName = this.userService.getUser().getUserName();
  userId = this.userService.getUser().getUserId();
  msg = 'Welcome '+ this.userName + ' to ';
  msgList = [];
  
  textType: any = 'Plain Text';
  textTypeList: any = ['Plain Text', 'Sign Language'];
  surveyValue:any ;
  isSurvey:boolean = false;
  isoffers:boolean = false;
  branchGuidList = [];
  
  themeCover = 'assets/img/ionic4-Start-Theme-cover.jpg';

  constructor(
    public navCtrl: NavController,
    public menuCtrl: MenuController,
    public popoverCtrl: PopoverController,
    public alertCtrl: AlertController,
    public modalCtrl: ModalController,
    public toastCtrl: ToastController,
     private userService: UserService,
     private httpService: HttpService,
     public f: SpeechSynthesisUtteranceFactoryService,
     public svc: SpeechSynthesisService
  ) {

  }

  ngOnInit() {
    
   IntervalObservable.create(3000).subscribe(() => {
   this.httpService.processCustomer({id : this.userId}).subscribe( (response) => {
     if(response != null){
        this.msg = this.msg + response.name + " branch. I'm " + response.branchMgr +
          ' ,the branch manager. Please have a seat while I send an authorized person to assist you.';
          this.msgList.push(this.msg);
        this.svc.speak(this.f.text(this.msg));
      }
    })
  })
     IntervalObservable.create(2000).subscribe(() => {
      this.httpService.getCustAllocation({id : this.userId}).subscribe( (response) => {
      if(response != null){
        this.msg='';
        this.msg = 'Dear ' + this.userName + ', our branch representative '+ response.branchEmpName;
        this.msg = this.msg  +' will arrive in '+ response.estTime + ' mins and assist you further.';
        this.msg = this.msg  + 'OTP is ' + response.otp +', you are requested to validate the same with';
        this.msg = this.msg  + ' the bank representative';
        this.msgList.push(this.msg);
        this.svc.speak(this.f.text(this.msg));
        }
      })
    })

    IntervalObservable.create(3000).subscribe(() => {
      this.httpService.processCustomerLeave({id : this.userId}).subscribe( (response) => {
       if(response != null){
          this.isSurvey = true;
          this.svc.speak(this.f.text('Thank you for visiting the branch. Kindly rate your experience'));
       }
       })
     })

     IntervalObservable.create(3000).subscribe(() => {
      this.httpService.getAtmCustNotification({id : this.userId }).subscribe( (response) => {
        console.log(response);
        if(response != null){
          this.isoffers = true;
          this.branchGuidList.push(response.branchGuid);
          
        }
      })
    })
   /* IntervalObservable.create(3000).subscribe(() => {
      this.httpService.getAtmCustNotification({id : this.userId }).subscribe( (response) => {
        console.log(response);
        if(response != null){
          this.isoffers = true;
          this.branchGuidList.push(response.branchGuid);
          
        }
      })
    })*/
  }

  onClickComplete(){
    this.isSurvey = false;
    this.msg = 'Thank you for your feedback. Have a good day ahead';
    this.msgList.push(this.msg);
    this.svc.speak(this.f.text(this.msg));
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(true);
  }

  settings() {
    this.navCtrl.navigateForward('settings');
  }

  async alertLocation() {
    const changeLocation = await this.alertCtrl.create({
      header: 'Change Location',
      message: 'Type your Address.',
      inputs: [
        {
          name: 'location',
          placeholder: 'Enter your new Location',
          type: 'text'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    changeLocation.present();
  }

  async searchFilter () {
    const modal = await this.modalCtrl.create({
      component: SearchFilterPage
    });
    return await modal.present();
  }

  async presentImage(image: any) {
    const modal = await this.modalCtrl.create({
      component: ImagePage,
      componentProps: { value: image }
    });
    return await modal.present();
  }

  async notifications(ev: any) {
    const popover = await this.popoverCtrl.create({
      component: NotificationsComponent,
      event: ev,
      animated: true,
      showBackdrop: true
    });
    return await popover.present();
  }

}
