import { Component, OnInit } from '@angular/core';
import { IntervalObservable } from "rxjs/observable/IntervalObservable";
import { HttpService } from './../../services/http.service'
import { UserService } from './../../services/user.service'
import { SpeechSynthesisUtteranceFactoryService, SpeechSynthesisService } from '@kamiazya/ngx-speech-synthesis';


@Component({
  selector: 'app-about',
  templateUrl: './about.page.html',
  styleUrls: ['./about.page.scss'],
})
export class AboutPage implements OnInit {

  isHome:boolean = false;
  isTrans:boolean = false;
  isSuccess:boolean = false;
  userId = this.userService.getUser().getUserId();
  msg:string = '';

  constructor(private httpService: HttpService,
    private userService: UserService,
    public f: SpeechSynthesisUtteranceFactoryService,
    public svc: SpeechSynthesisService) { }

  ngOnInit() {
    IntervalObservable.create(3000).subscribe(() => {
      this.httpService.getAtmCustNotification({id : this.userId }).subscribe( (response) => {
        console.log(response);
        if(response != null){
          this.isHome = true;
          this.isTrans = false;
           this.isSuccess = false;
           this.msg = 'Welcome, ' + response.custName + ' . Please enter your PIN';
           this.svc.speak(this.f.text(this.msg));
        }
      })
    })
    /*this.httpService.getAtmCustNotification({id : this.userId }).subscribe( (response) => {
      console.log(response);
      if(response != null){
        this.isHome = true;
        this.isTrans = false;
         this.isSuccess = false;
      }
    })*/
  
  }

  onClickHome(){
    this.isHome = false;
    this.isTrans = true;
    this.isSuccess = false;
    this.msg = 'Please enter your amount to withdraw';
    this.svc.speak(this.f.text(this.msg));
  }

  onClickTrans(){
    this.isHome = false;
    this.isTrans = false;
    this.isSuccess = true;
    this.msg = 'Your transaction is successful. Have a nice day'
    this.svc.speak(this.f.text(this.msg));
  }



}
