import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from './../../environments/environment'
import { Customer} from './../model/Customer'


@Injectable({
  providedIn: 'root'
})
export class HttpService { 

  constructor(private http: HttpClient) { }

  authenticate(data:string): Observable<any> {
    return this.http.post(environment.AUTH_SERVICE, data,
       {headers: {"Content-Type": "application/x-www-form-urlencoded"},observe: 'response'});
    } 

    getUserRole(data:any): Observable<any> {
      return this.http.get(environment.USER_ROLE, {params : data });
    }

    getBranchDetails(data:any): Observable<any> {
      return this.http.get(environment.BRANCH_DETAILS, {params : data });
    }

    processCustomer(data:any): Observable<any> {
      return this.http.get(environment.PROCESS_CUST, {params : data });
    }

    processCustomerLeave(data:any): Observable<any> {
      return this.http.get(environment.PROCESS_CUST_LEAVE, {params : data });
    }

    getCustNotification(data:any): Observable<any> {
      return this.http.get(environment.CUST_NOTIFICATION, {params : data });
     }

     getAtmCustNotification(data:any): Observable<any> {
      return this.http.get(environment.ATM_CUST_NOTIFICATION, {params : data });
     }

     saveBranchMsg(data:any): Observable<any> {
      return this.http.post(environment.BRANCH_MSG,  data );
    }

    getCustAllocation(data:any): Observable<any> {
      return this.http.get(environment.CUST_ALLOCATION, {params : data });
     }

}
