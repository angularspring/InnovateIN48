export class Workflow {

    private id:number;
    private bankId:string;
    private createdUser:string;
    private createdDateStr:string;
    private screenName:string;
    private status:string;
    private serialNo:number;
    private authorisedUser:string;
    private authorisedDateStr:string;
    private postedBankId:string;
    private actionName:string;
    private rejectedReason:string;
    private remarks:string;

    

}