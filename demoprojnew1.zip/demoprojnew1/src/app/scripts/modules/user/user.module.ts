

import { UserDetailsComponent } from './../../components/user/user-details.component';
import { UserHomeComponent } from './../../components/user/user-home.component';
import { UserMaintService } from './../../services/userMaint.service';
import { CommonFeaturesModule } from './../common/common.module';
import { NgModule } from '@angular/core';
import { UIRouterModule } from '@uirouter/angular';
import { Ng2StateDeclaration } from '@uirouter/angular';


const userHomeState: Ng2StateDeclaration = {
  name: 'user.home',
  component: UserHomeComponent
  /*views: {
    '^.^.$default': {
      component: UserHomeComponent,
    }
  },*/
};

const userDetailsState: Ng2StateDeclaration = {
  name: 'user.details',
  component: UserDetailsComponent
 /* views: {
    '^.^.$default': {
      component: UserDetailsComponent,
    }
  },*/
};

const USER_STATES = [
  userDetailsState,
  userHomeState
];

@NgModule({
  imports: [
    UIRouterModule.forChild({ states: USER_STATES }),
    CommonFeaturesModule.forRoot()
  ],
  declarations: [
    UserDetailsComponent,
    UserHomeComponent],
    providers: [UserMaintService],
})
export class UserModule { }

