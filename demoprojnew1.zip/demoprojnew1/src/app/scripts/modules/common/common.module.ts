import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CustomTranslateLoader } from './../../components/common/custom.http.loader'

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
     TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          //useClass: CustomTranslateLoader,
          deps: [HttpClient]
      }
    })
  ],
  exports: [
    TranslateModule,
    CommonModule,
    FormsModule
  ],
  declarations: []
})
export class CommonFeaturesModule {
  static forRoot(): ModuleWithProviders {
  return { ngModule: CommonFeaturesModule };
} }

// required for AOT compilation
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}