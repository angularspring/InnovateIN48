/// <reference types="crypto-js" />

import { Component, OnInit } from '@angular/core';
import { StateService } from '@uirouter/angular';
import { AuthService } from './../../services/auth.service'
import { UserService } from './../../services/user.service'
import { NavigationService } from './../../services/navigation.service'
import { MenuService } from './../../services/menu.service'
import { User } from './../../models/User';
import { NavLinks } from './../../models/navLinks';
import { NgForm } from '@angular/forms'
import { Menu } from '../../models/Menu';
import { HttpService } from './../../services/http.service'
import * as CryptoJS from 'crypto-js';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './../../../views/login.component.html',
})
export class LoginComponent implements OnInit {

  user:User;
  login:any = {};
  
    

  constructor(private httpService: HttpService, private state: StateService, private authService: AuthService, 
              private userService: UserService,private navigationService: NavigationService,
               private menuService: MenuService,private translate: TranslateService) { 
    
  }

  ngOnInit() {
    this.login.isSubmitted = false;
    this.login.isError = false;
  }

  onSubmit(form : NgForm){
    this.login.isSubmitted = true;
    if(form.valid){
      let tokenData = this.login.userId + "BANKADMIN";
      this.httpService.getToken(tokenData).subscribe( (response) => {
       let encrypted_pwd = CryptoJS.AES.encrypt(this.login.pwd, CryptoJS.enc.Base64.parse(response[0]),{mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 }).toString();
        encrypted_pwd = encrypted_pwd.replace(/\+/g,'AB1');
        /*let formData = new FormData();
        formData.append("j_username", this.login.userId);
        formData.append("j_pwd", encrypted_pwd);
        formData.append("j_bankId", "BANKADMIN");
        this.httpService.authenticate(formData).subscribe( (resp) => {*/
          let data ="j_username=" + this.login.userId +"&j_pwd=" + encrypted_pwd +"&j_bankId=" + "BANKADMIN" +"&submit=Login";
                
        this.httpService.authenticate(data).subscribe( (resp) => {
        
          console.log(resp);
          this.authService.setIsLoggedIn(true);
          this.user = new User();
          this.user.setUserId(this.login.userId);
          this.userService.setUser(this.user);
          let tabId:any[] = [0,1,2,3];
          let menuList:NavLinks[] = this.navigationService.getUserMenuList(tabId);
          let menu:Menu = new Menu();
          menu.setMenuList(menuList);
          this.menuService.setMenu(menu);
          this.state.go("user.home"); 
        }, 
        error => {
          this.login.isError = true;
          this.login.userId = "";
          this.login.pwd = "";
          this.login.isSubmitted = false;
          let status = error.status;
          if(status=="401"){
            this.login.errorMsg =  this.translate.instant("login.form.auth.fail");
         }
          else if(status=="423"){
            this.login.errorMsg =  this.translate.instant("login.form.max.attempt");
          }
          else if(status=="420"){
            this.login.errorMsg =  this.translate.instant("login.form.logn.blocked");
          }
          else if(status=="440"){
            this.login.errorMsg =  this.translate.instant("login.form.user.invalid");
          }
          else if(status=="444"){
            this.login.errorMsg =  this.translate.instant("login.form.login.error");
          }
          else if(status=="426"){
            this.login.errorMsg =  this.translate.instant("login.form.user.blocked");
          }
            else if(status=="429"){
              this.login.errorMsg =  this.translate.instant("login.form.user.inactive");
          }  else if(status=="421"){
            this.login.errorMsg =  this.translate.instant("login.form.session.inactive");
         }
        })
      })
    }
  }

  clear(): void{
      this.login.userId = "";
      this.login.pwd = "";
  }

}
