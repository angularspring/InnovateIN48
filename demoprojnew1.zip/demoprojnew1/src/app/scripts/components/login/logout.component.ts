import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './../../../views/logout.component.html',
})
export class LogoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  

}
