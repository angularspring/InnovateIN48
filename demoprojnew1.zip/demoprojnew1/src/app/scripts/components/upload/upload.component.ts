import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpService } from './../../services/http.service'
import { HttpParams } from '@angular/common/http'

@Component({
  templateUrl: './../../../views/upload.component.html'
})
export class UploadComponent implements OnInit {

  upload:any = {}; 

  @ViewChild('fileInput') el:ElementRef;
  constructor(private httpService: HttpService) { }

  ngOnInit() {
  }

  onSubmit(){
    let file = this.el.nativeElement.files[0];
    console.log(file);
    let formData = new FormData();
    let  httpParams = new HttpParams();
    formData.append("file", file);
    let data = JSON.stringify({
      test:"test"
    });
    formData.append("data",data);
    this.httpService.uploadFile(formData).subscribe((data) => console.log(data));
    
  }

}
