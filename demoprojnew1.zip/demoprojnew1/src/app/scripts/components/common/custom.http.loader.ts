import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import { TranslateLoader } from '@ngx-translate/core';
import {Observable} from 'rxjs';

@Injectable()
export class CustomTranslateLoader implements TranslateLoader  {
    

    constructor(private http: HttpClient) {}
    getTranslation(lang: string): Observable<any>{
        var apiAddress = "/admin/assets/i18n/"+ lang+".json";
        return this.http.get(apiAddress, { headers: {"Content-Type": "application/json"}});
    }
}