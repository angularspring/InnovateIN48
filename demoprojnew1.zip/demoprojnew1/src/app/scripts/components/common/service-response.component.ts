import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  templateUrl: './service-response.component.html',
})
export class ServiceResponseComponent implements OnInit {

  serviceErrorMessage: string;

  constructor(private activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

  dismiss(){
    this.activeModal.dismiss();
  }

  onClickOk(){
    this.activeModal.dismiss();
  }
}
