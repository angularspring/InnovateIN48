import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpXsrfTokenExtractor
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable()
export class HttpReqInterceptor implements HttpInterceptor {

  constructor(private tokenExtractor: HttpXsrfTokenExtractor) {
  }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      console.log("coming here");
      const headerName = 'XSRF-TOKEN';
      const respHeaderName = 'X-XSRF-TOKEN';
      console.log(document.cookie);
      let token = this.tokenExtractor.getToken() as string;
      //document.cookie = 'CSRF-TOKEN=' + this.token();
      //document.cookie = 'XSRF-TOKEN=' + "123$$";
     
      console.log(token);
      //request.clone({ headers: request.headers.set(respHeaderName, token)  });
        return next.handle(request);

      }

      token(a?: any){
        return a?(a^this.getRandomNum()*16>>a/4).toString(16):(1e16+1e16).toString().replace(/[01]/g,this.token())
      }; 

      getRandomNum () {
        let cryptoObj = window.crypto;
        let randomNums = new Uint32Array(3);
          cryptoObj.getRandomValues(randomNums);
          let randomNumber=Number((randomNums[0]+""+randomNums[1]).substring(0, 16));
          return randomNumber/(Math.pow(10,16));
      }
}