import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {ServiceResponseComponent} from './../../components/common/service-response.component';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

    constructor(private modalService: NgbModal) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
       return next.handle(request).pipe(catchError(err => {
        
        if (err.status === 404 || err.status === 503 || err.status === 500 ||  err.status === 400) {
            const modalRef = this.modalService.open(ServiceResponseComponent);
            modalRef.componentInstance.serviceErrorMessage = 'Unable to process your request';
        }

           /*if (err.status === 401) {
                console.log("error");
            }
            let error = "";
            if(!!err && !!err.error && err.error.message){
                error = err.error.message;
            }else if(!!err && err.statusText){
                error = err.statusText;
            }*/
            
            return throwError(err);
        }))

      }
}