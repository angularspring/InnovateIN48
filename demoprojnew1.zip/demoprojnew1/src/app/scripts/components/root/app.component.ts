import { Component, OnInit } from '@angular/core';
import { AuthService } from './../../services/auth.service'
import { UserService } from './../../services/user.service'
import { MenuService } from './../../services/menu.service'
import { User } from './../../models/User';
import { NavLinks } from './../../models/navLinks';
import { StateService } from '@uirouter/angular';
import {TranslateService} from '@ngx-translate/core';
import { HostListener } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {ServiceResponseComponent} from './../common/service-response.component';
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-root',
  templateUrl: './../../../views/app.component.html',
  styleUrls: ['./../../../css/app.component.css'],
  host: {
    '(document:keydown)': 'timeOutResetter($event)',
    '(document:keyup)': 'timeOutResetter($event)',
    '(document:click)': 'timeOutResetter($event)',
    '(document:mousemove)': 'timeOutResetter($event)',
    '(document:DOMMouseScroll)': 'timeOutResetter($event)',
    '(document:mousewheel)': 'timeOutResetter($event)',
    '(document:mousedown)': 'timeOutResetter($event)',
    '(document:touchstart)': 'timeOutResetter($event)',
    '(document:touchmove)': 'timeOutResetter($event)',
    '(document:scroll)': 'timeOutResetter($event)',
    '(document:focus)': 'timeOutResetter($event)',
  }
})
export class AppComponent implements OnInit{
  title = 'demoproj';
  //authData:any = {};
  authData:any = {};
  user:User;
  menuList: NavLinks[];
  langList:any = {};
  lang:any;
  timeOutThread: any;
  timeOutValue = 10*1000;

  private authSubscription: Subscription;
  private userSubscription: Subscription;
  private menuSubscription: Subscription;
    
  constructor(private state: StateService, private authService: AuthService,private userService: UserService,
             private menuService:MenuService, private translate: TranslateService,
             private modalService: NgbModal) { 
    this.authData.isLoggedIn = false;
    this.translate.setDefaultLang('en');
    this.langList = [{code:"en",value:"English"},{code:"hi",value:"Hindi"}];
    this.lang = "en";
    
    /*let timeOutValue = 10*1000;
    console.log("coming here");
    this.timeOutFunc(timeOutValue);
    let array = ['keydown', 'keyup', 'click', 'mousemove', 'DOMMouseScroll', 'mousewheel', 'mousedown', 'touchstart', 'touchmove', 'scroll', 'focus'];
    for (var value of array) {
      console.log("value->"+value);
      Document.bind((event) => {
        console.log("binding");
        this.timeOutResetter(timeOutValue);
      });
    } */
    this.timeOutFunc();
   
  }

  ngOnInit() {
      this.authSubscription = this.authService.loggedInChange.subscribe((data) => {
        this.authData.isLoggedIn = data;
      }); 
      this.userSubscription = this.userService.userObs.subscribe((data) => {
        this.user = data;
      }); 
      this.menuSubscription = this.menuService.menuObs.subscribe((data) => {
        this.menuList = data.getMenuList();
      });
     
    
    }

    logout(): void {
      this.authService.setIsLoggedIn(false);
      this.menuList = this.menuList.splice(0,this.menuList.length);
      this.state.go("login");
    }

    loadView(stateName: string): void{
      this.state.go(stateName);
    
    
  }

  changeLanguage(){
    this.translate.use(this.lang);
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) { 
    if(this.authData.isLoggedIn){
      let input_key = event.keyCode;
      if (input_key === 116 || input_key === 121 || input_key === 122 || input_key === 123) { //F5, F10, F11, F12
        this.disableKeyboardNavigation(event);	
      }else if(event.ctrlKey) { // Ctrl + R, Ctrl + Shift + R
        if (input_key === 82 ) { 
          this.disableKeyboardNavigation(event);	
        } 
      }		
    }
  }

  disableKeyboardNavigation(event: KeyboardEvent){
    const modalRef = this.modalService.open(ServiceResponseComponent);
   modalRef.componentInstance.serviceErrorMessage = 'This operation is not allowed';
    event.preventDefault();
    event.stopPropagation();
  }

 
  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    
    if(this.authData.isLoggedIn){
      this.logout();
    }
    event.preventDefault();
		event.stopPropagation();
    
  }

  

  @HostListener('window:beforeunload', ['$event'])
  onBeforeUnload(event) {
    event.returnValue=true;
    
  }

  ngOnDestroy() {
    this.authSubscription.unsubscribe();
    this.userSubscription.unsubscribe();
    this.menuSubscription.unsubscribe();
    clearTimeout(this.timeOutThread);
  }

  timeOutResetter(event: Event){
    clearTimeout(this.timeOutThread);
    this.timeOutFunc();
  }

  timeOutFunc(){
    this.timeOutThread = setTimeout(() => {
      if(this.authData.isLoggedIn){
        this.state.go("logout");
      }
   }, this.timeOutValue);
  }
  
}


