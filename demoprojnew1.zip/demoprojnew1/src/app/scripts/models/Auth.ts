export interface Authorisation {

    id:number;
    bankId:string;
    createdUser:string;
    createdDateStr:string;
     screenName:string;
     status:string;
     serialNo:number;
     authorisedUser:string;
     authorisedDateStr:string;
     postedBankId:string;
     actionName:string;
     rejectedReason:string;
     remarks:string;

    

}